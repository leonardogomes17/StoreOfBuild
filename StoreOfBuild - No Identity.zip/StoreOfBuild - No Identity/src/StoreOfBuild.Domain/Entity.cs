namespace StoreOfBuild.Domain
{
    public class Entity
    {
        public int Id {get; protected set; }
    }
}